<?php $this->load->view('templates/header'); ?>

<div class="container my-4">
  <h3 class="fw-bold mb-4">📜 My Accepted Quests</h3>

  <div class="row g-3">
    <?php if (!empty($accepted_quests)): ?>
      <?php foreach ($accepted_quests as $quest): ?>
        <div class="col-md-6">
          <div class="card border-0 shadow-sm rounded-3">
            <div class="card-body">
              <div class="d-flex justify-content-between align-items-start mb-2">
                <h5 class="card-title fw-bold m-0"><?php echo html_escape($quest['title']); ?></h5>
                <span class="badge bg-warning text-dark fw-bold">🪙 <?php echo html_escape($quest['reward']); ?> GP</span>
              </div>
              <p class="card-text text-secondary small mb-3"><?php echo html_escape($quest['description']); ?></p>
              
              <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                <span class="badge bg-info text-dark fw-semibold">In Progress</span>
                <button class="btn btn-success btn-sm fw-bold" data-bs-toggle="modal" data-bs-target="#completeModal<?php echo $quest['id']; ?>">
                  Complete Quest
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- Completion Modal with Proof Upload for Each Quest -->
        <div class="modal fade" id="completeModal<?php echo $quest['id']; ?>" tabindex="-1">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title fw-bold">Upload Completion Proof</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
              </div>
              <?php echo form_open_multipart('QuestController/complete_quest_with_proof/' . $quest['id']); ?>
                <div class="modal-body">
                  <p class="small text-muted mb-3">Attach a screenshot or document proving completion. It will be saved and sent via email notification.</p>
                  <div class="mb-3">
                    <label class="form-label fw-semibold">Proof Screenshot / Document (JPG, PNG, PDF)</label>
                    <input type="file" name="proof_file" class="form-control" required>
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                  <button type="submit" class="btn btn-success fw-bold">Submit Proof & Complete</button>
                </div>
              <?php echo form_close(); ?>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    <?php else: ?>
      <div class="col-12 text-center py-5">
        <p class="text-muted fs-5">You have no active quests in progress right now.</p>
        <a href="<?php echo site_url('QuestController/home'); ?>" class="btn btn-primary fw-bold">Browse Quest Board</a>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php $this->load->view('templates/footer'); ?>