<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quest History</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-0"><i class="fa-solid fa-clock-rotate-left text-primary me-2"></i>Quest History</h2>
            <p class="text-muted mb-0">
                <?php echo !empty($is_master) ? 'Master View: View and filter all completed quest records.' : 'Worker View: Review your completed quests.'; ?>
            </p>
        </div>
        <a href="<?php echo site_url('QuestController/home'); ?>" class="btn btn-outline-secondary">
            <i class="fa-solid fa-arrow-left me-1"></i> Back to Dashboard
        </a>
    </div>

    <!-- Master Filter Form -->
    <?php if (!empty($is_master)): ?>
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body bg-white rounded">
                <form method="GET" action="<?php echo site_url('QuestController/history'); ?>" class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label for="worker_id" class="form-label fw-semibold">Filter by Worker</label>
                        <select name="worker_id" id="worker_id" class="form-select" onchange="this.form.submit()">
                            <option value="">-- All Workers --</option>
                            <?php if (!empty($workers)): ?>
                                <?php foreach ($workers as $worker): ?>
                                    <option value="<?php echo $worker['id']; ?>" <?php echo ($selected_worker == $worker['id']) ? 'selected' : ''; ?>>
                                        <?php echo html_escape($worker['username']); ?>
                                    </option>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <?php if (!empty($selected_worker)): ?>
                        <div class="col-md-2">
                            <a href="<?php echo site_url('QuestController/history'); ?>" class="btn btn-light text-danger w-100 border">
                                <i class="fa-solid fa-xmark me-1"></i> Clear Filter
                            </a>
                        </div>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <!-- Flash Notifications -->
    <?php if ($this->session->flashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $this->session->flashdata('success'); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if ($this->session->flashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $this->session->flashdata('error'); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Quest History Table -->
    <div class="card shadow-sm border-0">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th scope="col" class="ps-4">ID</th>
                            <th scope="col">Quest Title</th>
                            <th scope="col">Description</th>
                            <th scope="col">Reward</th>
                            <th scope="col">Status</th>
                            <th scope="col">Proof File</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($completed_quests)): ?>
                            <?php foreach ($completed_quests as $quest): ?>
                                <tr>
                                    <td class="ps-4 fw-bold">#<?php echo $quest['id']; ?></td>
                                    <td class="fw-semibold text-dark"><?php echo html_escape($quest['title']); ?></td>
                                    <td>
                                        <span class="d-inline-block text-truncate" style="max-width: 250px;">
                                            <?php echo html_escape($quest['description']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-success-subtle text-success border border-success fw-bold px-2 py-1">
                                            $<?php echo number_format($quest['reward'], 2); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-success text-white">
                                            <i class="fa-solid fa-circle-check me-1"></i> Completed
                                        </span>
                                    </td>
                                    <td>
                                        <?php if (!empty($quest['proof_file'])): ?>
                                            <a href="<?php echo base_url('uploads/' . $quest['proof_file']); ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                                <i class="fa-solid fa-paperclip me-1"></i> View Proof
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted small">No attachment</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-5 text-muted">
                                    <i class="fa-solid fa-box-open fa-3x mb-3 text-secondary d-block"></i>
                                    <h5>No completed quests found</h5>
                                    <p class="small mb-0">There are no completed quest records matching this view.</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap 5 JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/bootstrap.bundle.min.js"></script>
</body>
</html>