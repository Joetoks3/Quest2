<nav class="col-md-3 col-lg-2 d-md-block bg-white sidebar border-end min-vh-100 py-3">
  <div class="position-sticky">
    <ul class="nav nav-pills flex-column gap-1">
      <li class="nav-item">
        <a href="<?php echo site_url('QuestController/home'); ?>" 
           class="nav-link <?php echo ($this->router->fetch_method() == 'home') ? 'active' : 'link-dark'; ?>">
          ⚔️ Quests Board
        </a>
      </li>
      <li class="nav-item">
        <a href="<?php echo site_url('QuestController/my_quests'); ?>" 
           class="nav-link <?php echo ($this->router->fetch_method() == 'my_quests') ? 'active' : 'link-dark'; ?>">
          🛡️ My Accepted Quests
        </a>
      </li>
      <li class="nav-item">
        <a href="<?php echo site_url('QuestController/history'); ?>" 
           class="nav-link <?php echo ($this->router->fetch_method() == 'history') ? 'active' : 'link-dark'; ?>">
          📜 Quest History
        </a>
      </li>
    </ul>
  </div>
</nav>