</main> <!-- Close Main -->
    </div> <!-- Close Row -->
  </div> <!-- Close Container -->

  <script src="<?php echo base_url('assets/js/bootstrap.bundle.min.js'); ?>"></script>
  <script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
  <script>
    alertify.set('notifier','position', 'top-right');
    <?php if($this->session->flashdata('success')): ?>
      alertify.success(<?php echo json_encode($this->session->flashdata('success')); ?>);
    <?php endif; ?>
    <?php if($this->session->flashdata('error')): ?>
      alertify.error(<?php echo json_encode($this->session->flashdata('error')); ?>);
    <?php endif; ?>
  </script>
</body>
</html>