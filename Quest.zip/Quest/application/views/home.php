<?php $this->load->view('templates/header'); ?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<div class="container my-4">

  <!-- Analytics, Excel Upload, & Manual Email Row -->
  <div class="row mb-4 g-3">
    <!-- Dynamic Graph Dashboard -->
    <div class="col-md-6">
      <div class="card border-0 shadow-sm p-3 bg-white rounded-3 h-100">
        <h5 class="fw-bold mb-3">📊 Quest Board Statistics</h5>
        <div style="height: 220px;">
          <canvas id="questStatusChart"></canvas>
        </div>
      </div>
    </div>

    <!-- Excel Uploading (Composer) -->
    <div class="col-md-3">
      <div class="card border-0 shadow-sm p-3 bg-white rounded-3 h-100">
        <h5 class="fw-bold mb-2">📁 Import Quests (Excel)</h5>
        <p class="text-muted small mb-3">Upload an <code>.xlsx</code> file parsed via PhpSpreadsheet.</p>
        
        <?php echo form_open_multipart('QuestController/upload_excel'); ?>
          <div class="mb-3">
            <input type="file" name="excel_file" class="form-control form-control-sm" accept=".xls,.xlsx" required>
          </div>
          <button type="submit" class="btn btn-primary btn-sm w-100 fw-bold">Upload & Read Excel</button>
        <?php echo form_close(); ?>
      </div>
    </div>

    <!-- Manual Email with Attachment -->
    <div class="col-md-3">
      <div class="card border-0 shadow-sm p-3 bg-white rounded-3 h-100">
        <h5 class="fw-bold mb-2">✉️ Send Attachment Email</h5>
        <?php echo form_open_multipart('QuestController/send_custom_email'); ?>
          <div class="mb-2">
            <!-- Changed type to "text" so the browser allows comma-separated emails -->
            <input type="text" name="recipient" class="form-control form-control-sm" placeholder="Emails (separated by commas)" required>
          </div>
          <div class="mb-2">
            <input type="text" name="subject" class="form-control form-control-sm" placeholder="Subject" required>
          </div>
          <div class="mb-2">
            <textarea name="message" class="form-control form-control-sm" rows="1" placeholder="Message..." required></textarea>
          </div>
          <div class="mb-2">
            <input type="file" name="attachment" class="form-control form-control-sm">
          </div>
          <button type="submit" class="btn btn-success btn-sm w-100 fw-bold">Send Email</button>
        <?php echo form_close(); ?>
      </div>
    </div>
  </div>

  <!-- Active Quests Board Header -->
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="fw-bold m-0">⚔️ Available Quests</h3>
    <button type="button" class="btn btn-primary fw-bold" data-bs-toggle="modal" data-bs-target="#createQuestModal">
      + Post New Quest
    </button>
  </div>

  <!-- Quest Cards -->
  <div class="row g-3">
    <?php if (!empty($quests)): ?>
      <?php foreach ($quests as $quest): ?>
        <div class="col-md-4">
          <div class="card h-100 border-0 shadow-sm rounded-3">
            <div class="card-body d-flex flex-column">
              <div class="d-flex justify-content-between align-items-start mb-2">
                <h5 class="card-title fw-bold text-dark m-0"><?php echo html_escape($quest['title']); ?></h5>
                <span class="badge bg-warning text-dark fw-bold">🪙 <?php echo html_escape($quest['reward']); ?> GP</span>
              </div>
              <p class="card-text text-secondary small flex-grow-1"><?php echo html_escape($quest['description']); ?></p>
              
              <div class="d-flex justify-content-between align-items-center mt-3 pt-2 border-top">
                <small class="text-muted">Posted by: <strong><?php echo html_escape($quest['poster_name'] ?? 'User #' . $quest['poster_id']); ?></strong></small>
                
                <?php if ($quest['poster_id'] != $this->session->userdata('user_id')): ?>
                  <a href="<?php echo site_url('QuestController/accept_quest/' . $quest['id']); ?>" class="btn btn-sm btn-outline-primary fw-bold">Accept Quest</a>
                <?php else: ?>
                  <span class="badge bg-secondary">Your Quest</span>
                <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    <?php else: ?>
      <div class="col-12 text-center py-5">
        <p class="text-muted fs-5">No active quests available right now. Post one above!</p>
      </div>
    <?php endif; ?>
  </div>
</div>

<!-- Modal: Post New Quest -->
<div class="modal fade" id="createQuestModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title fw-bold">Post a New Quest</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <?php echo form_open('QuestController/create_quest'); ?>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label fw-semibold">Quest Title</label>
            <input type="text" name="title" class="form-control" placeholder="e.g. Slay the Dragon" required>
          </div>
          <div class="mb-3">
            <label class="form-label fw-semibold">Description</label>
            <textarea name="description" class="form-control" rows="3" placeholder="Provide details about the task..." required></textarea>
          </div>
          <div class="mb-3">
            <label class="form-label fw-semibold">Reward (Gold Pieces)</label>
            <input type="number" name="reward" class="form-control" placeholder="100" min="1" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary fw-bold">Post Quest</button>
        </div>
      <?php echo form_close(); ?>
    </div>
  </div>
</div>

<script>
  const ctx = document.getElementById('questStatusChart').getContext('2d');
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Open Quests', 'In Progress', 'Completed'],
      datasets: [{
        label: 'Total Quests',
        data: [<?php echo $open_count; ?>, <?php echo $accepted_count; ?>, <?php echo $completed_count; ?>],
        backgroundColor: ['#0d6efd', '#ffc107', '#198754'],
        borderRadius: 6
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } }
    }
  });
</script>

<?php $this->load->view('templates/footer'); ?>