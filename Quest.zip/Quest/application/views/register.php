<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Sign Up - Utosmation</title>
  <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>">
  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css"/>
  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/bootstrap.min.css"/>
</head>
<body class="bg-light d-flex align-items-center justify-content-center min-vh-100 py-4">

  <div class="card border-0 shadow-sm p-4 rounded-3 bg-white" style="width: 100%; max-width: 420px;">
    <h3 class="fw-bold mb-1 text-center">⚔️ Join Utosmation</h3>
    <p class="text-secondary small text-center mb-4">Create an account to start posting or taking quests.</p>
    
    <?php echo form_open('AuthController/process_register'); ?>
      <div class="mb-3">
        <label class="form-label text-secondary fw-semibold">Username</label>
        <input type="text" name="username" class="form-control" placeholder="username" value="<?php echo set_value('username'); ?>" required>
      </div>

      <div class="mb-3">
        <label class="form-label text-secondary fw-semibold">Email Address</label>
        <input type="email" name="email" class="form-control" placeholder="username" value="<?php echo set_value('email'); ?>" required>
      </div>

      <div class="mb-3">
        <label class="form-label text-secondary fw-semibold">Password</label>
        <input type="password" name="password" class="form-control" placeholder="password" required>
      </div>

      <div class="mb-3">
        <label class="form-label text-secondary fw-semibold">Confirm Password</label>
        <input type="password" name="confirm_password" class="form-control" placeholder="password" required>
      </div>

      <button type="submit" class="btn btn-primary w-100 fw-bold py-2 mt-2">Create Account</button>
    <?php echo form_close(); ?>

    <hr class="my-4 text-muted">

    <div class="text-center">
      <span class="text-secondary small">Already have an account?</span>
      <a href="<?php echo site_url('AuthController/login'); ?>" class="fw-bold text-decoration-none"> Sign In</a>
    </div>
  </div>

  <script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
  <script>
    alertify.set('notifier','position', 'top-right');
    <?php if($this->session->flashdata('error')): ?>
      alertify.error(<?php echo json_encode($this->session->flashdata('error')); ?>);
    <?php endif; ?>
  </script>
</body>
</html>