<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Login - Utosmation</title>
  <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>">
  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css"/>
  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/bootstrap.min.css"/>
</head>
<body class="bg-light d-flex align-items-center justify-content-center min-vh-100">

  <div class="card border-0 shadow-sm p-4 rounded-3 bg-white" style="width: 100%; max-width: 400px;">
    <h3 class="fw-bold mb-3 text-center">⚔️ Utosmation Login</h3>
    
    <?php echo form_open('AuthController/process_login'); ?>
      <div class="mb-3">
        <label class="form-label text-secondary fw-semibold">Email Address</label>
        <input type="email" name="email" class="form-control" placeholder="username" required>
      </div>

      <div class="mb-3">
        <label class="form-label text-secondary fw-semibold">Password</label>
        <input type="password" name="password" class="form-control" placeholder="password" required>
      </div>

      <button type="submit" class="btn btn-primary w-100 fw-bold">Sign In</button>
    <?php echo form_close(); ?>

    <hr class="my-4 text-muted">

    <div class="text-center">
      <span class="text-secondary small">Don't have an account yet?</span>
      <a href="<?php echo site_url('AuthController/register'); ?>" class="fw-bold text-decoration-none"> Sign Up</a>
    </div>
  </div>

  <script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
  <script>
    alertify.set('notifier','position', 'top-right');
    <?php if($this->session->flashdata('error')): ?>
      alertify.error(<?php echo json_encode($this->session->flashdata('error')); ?>);
    <?php endif; ?>
    <?php if($this->session->flashdata('success')): ?>
      alertify.success(<?php echo json_encode($this->session->flashdata('success')); ?>);
    <?php endif; ?>
  </script>
</body>
</html>