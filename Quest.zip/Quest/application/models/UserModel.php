<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UserModel extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function create_user($data) {
        // Hash password before saving to DB
        $data['password'] = password_hash($data['password'], PASSWORD_BCRYPT);
        return $this->db->insert('users', $data);
    }

    public function check_login($email, $password) {
        $this->db->where('email', $email);
        $query = $this->db->get('users');

        if ($query->num_rows() == 1) {
            $user = $query->row_array();
            // Verify typed plain-text password against stored bcrypt hash
            if (password_verify($password, $user['password'])) {
                return $user;
            }
        }
        return false;
    }
}