<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class QuestModel extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    // Get all open quests for the dashboard
    public function get_active_quests() {
        $this->db->select('quests.*, users.username as poster_name');
        $this->db->from('quests');
        $this->db->join('users', 'users.id = quests.poster_id', 'left');
        $this->db->where('quests.status', 'open');
        $this->db->order_by('quests.created_at', 'DESC');
        return $this->db->get()->result_array();
    }

    // Insert a new quest
    public function insert_quest($data) {
        return $this->db->insert('quests', $data);
    }

    // Accept a quest
    public function accept_quest($id, $user_id) {
        $data = [
            'status'      => 'accepted',
            'accepted_by' => $user_id
        ];
        $this->db->where('id', $id);
        $this->db->where('status', 'open');
        return $this->db->update('quests', $data);
    }

    // Get accepted quests for worker tracking
    public function get_accepted_quests($user_id) {
        $this->db->where('accepted_by', $user_id);
        $this->db->where('status', 'accepted');
        return $this->db->get('quests')->result_array();
    }

        /**
     * Fetch completed quests based on role and optional worker filter
     */
    public function get_completed_quests($user_id, $is_master = false, $filter_user_id = null) {
        $this->db->where('status', 'completed');

        if ($is_master) {
            // Master view: filter by specific worker if selected
            if (!empty($filter_user_id)) {
                $this->db->where('accepted_by', $filter_user_id);
            }
            // If no filter selected, master sees ALL completed quests
        } else {
            // Worker view: strictly show ONLY quests completed by them
            $this->db->where('accepted_by', $user_id);
        }

        return $this->db->order_by('id', 'DESC')
                        ->get('quests')
                        ->result_array();
    }

    /**
     * Fetch non-admin workers for the Master's filter dropdown
     */
    public function get_all_workers() {
        return $this->db->select('id, username')
                        ->where('is_admin', 0) // Only regular workers
                        ->get('users')
                        ->result_array();
    }
}