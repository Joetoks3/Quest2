<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Quest_lib {

    protected $CI;

    public function __construct() {
        $this->CI =& get_instance();
    }

    // Auth Guard: Enforce login requirement on protected pages
    public function require_login() {
        if (!$this->CI->session->userdata('logged_in')) {
            $this->CI->session->set_flashdata('error', 'Please log in to continue.');
            redirect('AuthController/login');
        }
    }

    // Helper: Get active session user ID
    public function user_id() {
        return $this->CI->session->userdata('user_id');
    }

    // Helper: Get active session username
    public function username() {
        return $this->CI->session->userdata('username');
    }

    public function is_master() {
        $user_id = $this->user_id();
        if (!$user_id) return false;

        // Check if session has is_admin, otherwise query the DB
        if ($this->CI->session->userdata('is_admin') !== NULL) {
            return (bool) $this->CI->session->userdata('is_admin');
        }

        $user = $this->CI->db->select('is_admin')
                             ->where('id', $user_id)
                             ->get('users')
                             ->row();

        return $user && (int)$user->is_admin === 1;
    }
}