<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use PhpOffice\PhpSpreadsheet\IOFactory;

class QuestController extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->quest_lib->require_login();
        $this->load->library('upload');
        $this->load->library('email');
    }

    public function index() {
        $this->home();
    }

    // Dashboard with Analytics & Active Quests
    public function home() {
        $user_id = $this->quest_lib->user_id();

        $data['open_count']      = $this->db->where('status', 'open')->count_all_results('quests');
        $data['accepted_count']  = $this->db->where('status', 'accepted')->count_all_results('quests');
        $data['completed_count'] = $this->db->where('status', 'completed')->count_all_results('quests');
        
        $data['quests'] = $this->QuestModel->get_active_quests();
        $this->load->view('home', $data);
    }

    // Post a New Quest
    public function create_quest() {
        $this->form_validation->set_rules('title', 'Quest Title', 'required|min_length[3]');
        $this->form_validation->set_rules('description', 'Description', 'required');
        $this->form_validation->set_rules('reward', 'Reward', 'required|numeric|greater_than[0]');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', strip_tags(validation_errors()));
        } else {
            $data = array(
                'title'       => $this->input->post('title'),
                'description' => $this->input->post('description'),
                'reward'      => $this->input->post('reward'),
                'poster_id'   => $this->quest_lib->user_id(),
                'status'      => 'open'
            );

            if ($this->QuestModel->insert_quest($data)) {
                $this->session->set_flashdata('success', 'Quest posted successfully!');
            } else {
                $this->session->set_flashdata('error', 'Failed to post quest in database.');
            }
        }
        redirect('QuestController/home');
    }

    // Accept a Quest
    public function accept_quest($id) {
        if ($this->QuestModel->accept_quest($id, $this->quest_lib->user_id())) {
            $this->session->set_flashdata('success', 'Quest accepted successfully!');
        } else {
            $this->session->set_flashdata('error', 'Unable to accept quest.');
        }
        redirect('QuestController/my_quests');
    }

    // Worker Tracking View
    public function my_quests() {
        $data['accepted_quests'] = $this->QuestModel->get_accepted_quests($this->quest_lib->user_id());
        $this->load->view('my_quests', $data);
    }

    // Manual Email Dispatcher with Multiple Recipients & File Attachment
    public function send_custom_email() {
        $this->form_validation->set_rules('recipient', 'Recipient Email(s)', 'required');
        $this->form_validation->set_rules('subject', 'Subject', 'required');
        $this->form_validation->set_rules('message', 'Message', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', strip_tags(validation_errors()));
            redirect('QuestController/home');
            return;
        }

        $upload_path = FCPATH . 'uploads/';
        if (!is_dir($upload_path)) {
            mkdir($upload_path, 0777, TRUE);
        }

        $config['upload_path']   = $upload_path;
        $config['allowed_types'] = 'jpg|jpeg|png|pdf|doc|docx|xls|xlsx';
        $config['max_size']      = 5120;
        $config['encrypt_name']  = TRUE;

        $this->upload->initialize($config);
        $attachment_path = NULL;

        if (!empty($_FILES['attachment']['name'])) {
            if ($this->upload->do_upload('attachment')) {
                $upload_data     = $this->upload->data();
                $attachment_path = $upload_data['full_path'];
            } else {
                $this->session->set_flashdata('error', $this->upload->display_errors('', ''));
                redirect('QuestController/home');
                return;
            }
        }

        // Parse comma-separated recipient emails into an array
        $raw_recipients   = $this->input->post('recipient');
        $recipients_array = array_map('trim', explode(',', $raw_recipients));

        // Fixed SMTP Configuration (Port 465 SSL)
        $smtp_config = array(
            'protocol'    => 'smtp',
            'smtp_host'   => 'ssl://smtp.gmail.com',
            'smtp_port'   => 465,
            'smtp_user'   => '2092515@g.cu.edu.ph', // Replace with your Gmail
            'smtp_pass'   => 'qeus nsyp bykb dfce',   // Replace with your 16-character App Password
            'mailtype'    => 'html',
            'charset'     => 'utf-8',
            'newline'     => "\r\n",
            'crlf'        => "\r\n",
            'smtp_timeout'=> 30
        );

        $this->email->initialize($smtp_config);
        $this->email->from('2092515@g.cu.edu.ph', 'Utosmation System');
        $this->email->to($recipients_array);
        $this->email->subject($this->input->post('subject'));
        $this->email->message(nl2br(html_escape($this->input->post('message'))));

        if ($attachment_path) {
            $this->email->attach($attachment_path);
        }

        if ($this->email->send()) {
            $this->session->set_flashdata('success', 'Email sent successfully to all recipients!');
        } else {
            $this->session->set_flashdata('error', 'Email failed to send. Check credentials or connection.');
        }

        redirect('QuestController/home');
    }

    // Excel File Upload & Database Batch Insert
    public function upload_excel() {
        $upload_path = FCPATH . 'uploads/';
        if (!is_dir($upload_path)) {
            mkdir($upload_path, 0777, TRUE);
        }

        $config['upload_path']   = $upload_path;
        $config['allowed_types'] = 'xls|xlsx';
        $config['max_size']      = 2048;
        $config['encrypt_name']  = TRUE;

        $this->upload->initialize($config);

        if (!$this->upload->do_upload('excel_file')) {
            $this->session->set_flashdata('error', $this->upload->display_errors('', ''));
        } else {
            $upload_data = $this->upload->data();
            $file_path   = $upload_data['full_path'];

            try {
                $spreadsheet = IOFactory::load($file_path);
                $sheetData   = $spreadsheet->getActiveSheet()->toArray();

                $inserted_count = 0;

                // Loop through rows skipping header (index 0)
                for ($i = 1; $i < count($sheetData); $i++) {
                    $title       = trim($sheetData[$i][0] ?? '');
                    $description = trim($sheetData[$i][1] ?? '');
                    $reward      = trim($sheetData[$i][2] ?? '');

                    if (!empty($title) && !empty($description)) {
                        $quest_data = array(
                            'title'       => $title,
                            'description' => $description,
                            'reward'      => is_numeric($reward) ? $reward : 100,
                            'poster_id'   => $this->quest_lib->user_id(),
                            'status'      => 'open'
                        );
                        $this->QuestModel->insert_quest($quest_data);
                        $inserted_count++;
                    }
                }

                $this->session->set_flashdata('success', "Success! Imported {$inserted_count} new quests into the database.");
            } catch (Exception $e) {
                $this->session->set_flashdata('error', 'Error reading Excel file: ' . $e->getMessage());
            }
        }
        redirect('QuestController/home');
    }

    // Complete Quest with Proof
    public function complete_quest_with_proof($id) {
        $upload_path = FCPATH . 'uploads/';
        if (!is_dir($upload_path)) {
            mkdir($upload_path, 0777, TRUE);
        }

        $config['upload_path']   = $upload_path;
        $config['allowed_types'] = 'jpg|jpeg|png|pdf';
        $config['max_size']      = 5120;
        $config['encrypt_name']  = TRUE;

        $this->upload->initialize($config);

        $proof_filename = NULL;

        if ($this->upload->do_upload('proof_file')) {
            $upload_data    = $this->upload->data();
            $proof_filename = $upload_data['file_name'];
        }

        if ($this->QuestModel->complete_quest($id, $this->quest_lib->user_id(), $proof_filename)) {
            $this->session->set_flashdata('success', '🎉 Quest marked as completed!');
        } else {
            $this->session->set_flashdata('error', 'Unable to complete quest.');
        }
        redirect('QuestController/my_quests');
    }

    // Quest History (Master sees all + filters, Worker sees only theirs)
    public function history() {
        $user_id   = $this->quest_lib->user_id();
        $is_master = $this->quest_lib->is_master(); // Checks if current logged-in user is master
        
        // Get selected worker filter ID from GET request (e.g., history?worker_id=3)
        $filter_user_id = $this->input->get('worker_id', TRUE);

        // Fetch completed quests according to role & filter
        $data['completed_quests'] = $this->QuestModel->get_completed_quests($user_id, $is_master, $filter_user_id);
        $data['is_master']        = $is_master;
        $data['selected_worker']  = $filter_user_id;

        // Pass workers list to view for the master's filter dropdown
        if ($is_master) {
            $data['workers'] = $this->QuestModel->get_all_workers();
        }

        $this->load->view('history', $data);
    }
}