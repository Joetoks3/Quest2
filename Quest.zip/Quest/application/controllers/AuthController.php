<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AuthController extends CI_Controller {

    public function login() {
        if ($this->session->userdata('logged_in')) {
            redirect('QuestController/home');
        }
        $this->load->view('login');
    }

    public function process_login() {
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors(' ', ' '));
            redirect('AuthController/login');
        } else {
            $email = $this->input->post('email');
            $password = $this->input->post('password');
            $user = $this->UserModel->check_login($email, $password);

            if ($user) {
               $session_data = array(
                    'user_id'   => $user['id'],
                    'username'  => $user['username'],
                    'email'     => $user['email'],
                    'is_admin'  => $user['is_admin'], // Store admin status
                    'logged_in' => TRUE
                );
                $this->session->set_userdata($session_data);
                $this->session->set_flashdata('success', 'Welcome back, ' . $user['username'] . '!');
                redirect('QuestController/home');
            } else {
                $this->session->set_flashdata('error', 'Invalid email or password.');
                redirect('AuthController/login');
            }
        }
    }

    // View Sign Up Page
    public function register() {
        if ($this->session->userdata('logged_in')) {
            redirect('QuestController/home');
        }
        $this->load->view('register');
    }

    // Process Registration Form
    public function process_register() {
        $this->form_validation->set_rules('username', 'Username', 'required|min_length[3]|max_length[50]');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]', [
            'is_unique' => 'This email is already registered.'
        ]);
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
        $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]', [
            'matches' => 'Passwords do not match.'
        ]);

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors(' ', ' '));
            redirect('AuthController/register');
        } else {
            $data = array(
                'username' => $this->input->post('username'),
                'email'    => $this->input->post('email'),
                'password' => $this->input->post('password')
            );

            if ($this->UserModel->create_user($data)) {
                $this->session->set_flashdata('success', 'Account created successfully! Please log in.');
                redirect('AuthController/login');
            } else {
                $this->session->set_flashdata('error', 'Failed to create account. Please try again.');
                redirect('AuthController/register');
            }
        }
    }

    public function logout() {
        $this->session->sess_destroy();
        redirect('AuthController/login');
    }
}